---
name: report
description: "Genera un report completo dello stato del progetto: avanzamento task, decisioni prese, coverage test, risultati validazione, e problemi noti."
---

# /vibecoding:report — Report di Progetto

## Cosa devi fare

Analizza lo stato attuale del progetto e genera un report completo leggibile dall'utente.

## Fonti da analizzare

1. **PLAN.md** → Stato di avanzamento dei task
2. **decisions.log** → Decisioni autonome prese
3. **VALIDATION_REPORT.md** → Risultati dell'ultima validazione (se esiste)
4. **Git log** → Commit effettuati, branch attivo
5. **Test suite** → Esegui i test e raccogli i risultati
6. **Codebase** → Conta file, righe di codice, complessità

## Output: REPORT.md

Genera `REPORT.md` nella root del progetto con:

```markdown
# REPORT — [Nome Progetto]
## Generato: [timestamp]

### Avanzamento
- Task completati: X/Y (Z%)
- Task in corso: ...
- Task bloccati: ...

### Metriche Codice
- File sorgente: N
- Righe di codice: N (esclusi test)
- Righe di test: N
- Rapporto test/codice: X:1

### Test
- Test totali: N
- Passati: N | Falliti: N | Skippati: N
- Coverage: X% (se disponibile)

### Validazione Prodotto
[Risultato ultima validazione o "Non ancora eseguita"]

### Decisioni Autonome Rilevanti
[Le 5 decisioni più significative da decisions.log]

### Problemi Noti
[Lista con severity]

### Prossimi Passi
[Task rimanenti da PLAN.md]
```

Non chiedere conferma. Genera il report, mostralo all'utente, e chiedi se vuole approfondire qualcosa.
