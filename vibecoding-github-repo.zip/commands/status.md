---
name: status
description: "Mostra un overview rapido dello stato del progetto: task completati, test, ultima validazione."
---

# /vibecoding:status — Stato Rapido

Leggi PLAN.md e mostra un riassunto compatto:

```
📋 PLAN: X/Y task completati (Z%)
🧪 TEST: [esegui test e mostra risultato sintetico]
✅ VALIDAZIONE: [ultima validazione o "mai eseguita"]
📝 DECISIONI: N decisioni loggate
🔄 ULTIMO COMMIT: [messaggio ultimo commit]
```

Non generare file. Rispondi inline nella chat. Sii conciso.
